# Admin
The Hydra 3.1 admin frontend.

## How to Run

https://cursos.luiztools.com.br/licoes/licao-00-ambiente/

## More

Follow me on social networks: https://about.me/luiztools

Receive news on Telegram: https://t.me/luiznews